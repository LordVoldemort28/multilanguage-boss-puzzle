module.exports = {
    manyMoves: manyMoves
}

var helpers = require( './helpers' );

function manyMoves(puzzle){
    
    function whatever(directions){
	return puzzle;
    }

    return whatever;
}
